import React, { useState } from 'react';
import './Login.css';
import { Link } from 'react-router-dom';
import { FaEnvelope, FaLock } from "react-icons/fa";

const Login = () => {
    const [username, setUsername] = useState('');
    const [password, setPassword] = useState('');

    const handleSubmit = (e) => {
        e.preventDefault();
        // Handle login logic here
        console.log('Logged in with:', username, password);
    };

    return (
        <div className="login-container">
            <h2 className="login-title">الدخول</h2>
            <form onSubmit={handleSubmit} className="login-form">
                <div className="form-columns">
                    <div className="form-column">
                        <div className="input-group">
                            <FaEnvelope className="icon" />
                            <label htmlFor="username">البريد الالكتروني</label>
                            <input
                                type="text"
                                id="username"
                                name="username"
                                value={username}
                                onChange={(e) => setUsername(e.target.value)}
                                required
                                className="input-field"
                            />
                        </div>
                        <div className="input-group">
                            <FaLock className="icon" />
                            <label htmlFor="password">كلمة المرور</label>
                            <input
                                type="password"
                                id="password"
                                name="password"
                                value={password}
                                onChange={(e) => setPassword(e.target.value)}
                                required
                                className="input-field"
                            />
                        </div>
                    </div>
                </div>
                <div className='register-link'>
                    <p>ليس لديك حساب؟ <Link to='/Signup'>انشاء حساب</Link></p>
                </div>
                <button type="submit" className="submit-button">تسجيل</button>
            </form>
        </div>
    );
};

export default Login;
